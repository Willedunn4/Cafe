#include <iostream>
#include <iomanip>

using namespace std;

int main() {
    
    double coffeePrice = 2.00;
    double blackCoffeePrice = 3.00;
    double croissantPrice = 4.25;
    double bagelPrice = 1.75;
    double lattePrice = 2.00;

   
    double userMoney = 10.00;

    
    const string currencySymbol = "$";

    
    cout << "Welcome to the Demon Cafe!" << endl;
    cout << "-------------------" << endl;
    cout << "Menu:" << endl;
    cout << "1. Coffee - " << currencySymbol << coffeePrice << endl;
    cout << "2. Black Coffee - " << currencySymbol << blackCoffeePrice << endl;
    cout << "3. Croissant - " << currencySymbol << croissantPrice << endl;
    cout << "4. Bagel - " << currencySymbol << bagelPrice << endl;
    cout << "5. Latte - " << currencySymbol << lattePrice << endl;

    
    int itemChoice;
    double totalCost = 0;
    cout << "Enter the number of the item you would like to purchase (0 to end): ";
    cin >> itemChoice;
    while (itemChoice != 0) {
        
        switch (itemChoice) {
        case 1:
            totalCost += coffeePrice;
            cout << "You have chosen Coffee." << endl;
            break;
        case 2:
            totalCost += blackCoffeePrice;
            cout << "You have chosen Black Coffee." << endl;
            break;
        case 3:
            totalCost += croissantPrice;
            cout << "You have chosen Croissant." << endl;
            break;
        case 4:
            totalCost += bagelPrice;
            cout << "You have chosen Bagel." << endl;
            break;
        case 5:
            totalCost += lattePrice;
            cout << "You have chosen Latte." << endl;
            break;
        default:
            cout << "Invalid item choice." << endl;
        }
       
        cout << "Enter the number of the item you would like to purchase (0 to end): ";
        cin >> itemChoice;
    }

    
    cout << "Total cost: " << currencySymbol << totalCost << endl;
    double userPayment;
    cout << "Enter the amount you would like to pay: ";
    cin >> userPayment;

    
    double change;
    if (userPayment < totalCost) {
        cout << "Insufficient payment." << endl;
        return 0;
    }
    else {
        change = userPayment - totalCost;
        cout << "Change: " << currencySymbol << change << endl;
    }

    
    userMoney -= totalCost;
    cout << "Your remaining money: " << currencySymbol << userMoney << endl;

    return 0;
}